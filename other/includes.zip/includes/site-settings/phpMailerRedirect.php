<?php if($status==1){ ?>
<script type="text/javascript">
    window.location.href='thank-you-for-contacting.php';
</script>
<?php } ?>