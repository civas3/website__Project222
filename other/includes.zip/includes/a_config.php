<?php
define('cdnURL', 'https://cdn.sukhi222.org/');
?>


