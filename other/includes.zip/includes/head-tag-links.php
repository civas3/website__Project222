        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!--FAVICON -->
        <!--local -->
           <!-- <link rel="shortcut icon" type="images/png" href="images/favicon/favicon.png"> -->
      <!--CDN GLOBAL -->
           <link rel="shortcut icon" type="images/png" href="<?php echo cdnURL ?>images/favicon/favicon.png"> 
      <!-- GOOGLE FONTS -->
           <link href="https://fonts.googleapis.com/css?family=Poppins|Roboto" rel="stylesheet">
           <!--<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">--> 
      <!-- JAVASCRIPT GLOBAL CDN -->
            <script type='text/javascript'>
                /*javascript global for using the CDN inside scripts */
                var cdnURL = '<?php echo cdnURL ?>';
            </script>
      <!--FONTAWASE ICONS -->
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <!-- CSS STYLESHEET -->
        <!--local-->
        <link rel="stylesheet" href="css/style.css">

        <!--CDN GLOBAL -->
            <!-- <link rel="stylesheet" href="<?php echo cdnURL ?>css/style.css"> -->
      <!-- JAVASCRIPT -->
        <!--local -->         
            <!-- <script src="js/sticky-nav.js"></script> -->
           <!-- <script src="js/transparent-nav.js"></script>  -->
        <!-- CDN GLOBAL -->
            <script src="<?php echo cdnURL ?>js/sticky-nav.js"></script> 
            <!-- <script src="<?php echo cdnURL ?>js/transparent-nav.js"></script>  -->

      <!--jQuery -- -->
        <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->
     <!-- GOOGLE ANALYTICS - Global site tag (gtag.js) -->
      <script async src="https://www.googletagmanager.com/gtag/js?id=UA-171295395-1"></script>
      <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-171295395-1');
      </script>

   