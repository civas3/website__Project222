<!--CDN-->
<script src="<?php echo cdnURL ?>js/accordion.js"></script> 
<script src="<?php echo cdnURL ?>js/top-nav.js"></script> 
 <script src="<?php echo cdnURL ?>js/body-scrolling-disabled-mobile-menu.js"></script> 
 <!-- <script src="<?php echo cdnURL ?>js/logo-carousel.js"></script>-->
<!--LOCAL-->
<!--<script src="js/body-scrolling-disabled-mobile-menu.js"></script> -->
<!-- <script src="js/accordion.js"></script>
<script src="js/top-nav.js"></script> -->



