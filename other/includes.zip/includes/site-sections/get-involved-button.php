<section id="btn-get-involved">
    <div class="row">
        <div class="col-12">
            <div class="section-content">
                <div class="section-content__nav-buttons get-involved-button ">
                    <div class="button-item">
                        <a class="btn btn-big " href="contact.php">
                            <span class="btn-span"></span>
                            <span class="btn-span"></span>
                            <span class="btn-span"></span>
                            <span class="btn-span"></span>GET INVOLVED</a>
                    </div>
                </div>
            </div>
        </div>
        <!--col-ends-->
    </div>
</section>