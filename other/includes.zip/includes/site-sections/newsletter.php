               

            <!--SECTION newsletter-->
            <section id="newsletter">
                <div class="row">
                    <div class="col-12-tab">
                        <div class="section-content">
                            <div class="section-content__info">
                                       
                                <form class="newsletter-form" action="../mail/subscribe.php" method="post">
                                        <label for="email"><b>SIGN UP TO RECEIVE UPDATES FROM THE SUKHI <span class="sukhi222-blue-span">2</span><span class="sukhi222-green-span">2</span><span class="sukhi222-red-span">2</span></b></label>
                                        <div>
                                        <input type="email" placeholder="Enter Your Email Address" name="email" required>
                                        <button type="submit" name="submit">Sign Up</button> 
                                        </div>                          
                                        <p>By clicking Sign Up, you agree to the SUKHI 222 Privacy and Cookie Notice. </p>
                                        <p><a href="terms-privacy.php">Terms & Privacy</a></p>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!--col-ends-->
                </div>
            </section>



