<title>THE LATEST NEWS AND HOTEST TOPICS IN THE HUMAN RIGHTS MOVEMENT</title>
<!--PAGE META DESCRIPTION-->    
    <meta name="description" content="A collection of articles, papers, and testimonials covering human rights, food water and shelter, and global events relating to the development and impact of the SUKHI 222 international movement. We welcome submissions to review for publication! Subscribe today! ">
<!--SOCIAL MEDIA-->
    <meta property="og:title" content="THE LATEST NEWS AND HOTEST TOPICS IN THE HUMAN RIGHTS MOVEMENT" />
    <meta property="og:description" content="A collection of articles, papers, and testimonials covering human rights, food water and shelter, and global events relating to the development and impact of the SUKHI 222 international movement. We welcome submissions to review for publication! Subscribe today! " />
    <meta property="og:image" content="http://www.whatever.com/images/header/human-right-project.jpg" />
    <meta name="twitter:card" content="summary_large_image" />

    