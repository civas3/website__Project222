<title>A MINIMUM OF 2 GALLONS A DAY OF CLEAN WATER FOR EVERY BODY AND MIND</title>
<!--PAGE META DESCRIPTION-->    
    <meta name="description" content="Using technology and sound practices we aim to foster a healthy and sustainable food and water supply throughout the planet with cooperation of all stake holders. We believe when basic needs are met, that the individual becomes sustainable and is able to contribute back to a civil society.">
<!--SOCIAL MEDIA-->
    <meta property="og:title" content="A MINIMUM OF 2 GALLONS A DAY OF CLEAN WATER FOR EVERY BODY AND MIND" />
    <meta property="og:description" content="Using technology and sound practices we aim to foster a healthy and sustainable food and water supply throughout the planet with cooperation of all stake holders. We believe when basic needs are met, that the individual becomes sustainable and is able to contribute back to a civil society." />
    <meta property="og:image" content="http://www.whatever.com/images/header/human-right-project.jpg" />
    <meta name="twitter:card" content="summary_large_image" />

