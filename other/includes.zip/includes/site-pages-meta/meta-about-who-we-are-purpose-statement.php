<title>SUKHI222 PURPOSE STATEMENT</title> 
<!--PAGE META DESCRIPTION-->    
    <meta name="description" content="Promote and help achieve the universal basic human right of the dignified access within civil society to a minimum of 2 gallons of clean water a day, 2000 nutritional calories and 200 ft.³ of secure shelter. ">
<!--SOCIAL MEDIA-->
    <meta property="og:title" content="SUKHI222 PURPOSE STATEMENT" />
    <meta property="og:description" content="Promote and help achieve the universal basic human right of the dignified access within civil society to a minimum of 2 gallons of clean water a day, 2000 nutritional calories and 200 ft.³ of secure shelter. " />
    <meta property="og:image" content="http://www.whatever.com/images/header/human-right-project.jpg" />
    <meta name="twitter:card" content="summary_large_image" />

    
 