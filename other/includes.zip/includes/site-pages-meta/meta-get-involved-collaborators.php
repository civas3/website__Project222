<title>WORK WITH THE BEST IN THE WORLD ON LIFE’S MOST URGENT NEEDS</title> 
<!--PAGE META DESCRIPTION-->    
    <meta name="description" content="Collaborate with other organizations and individuals to build a more peaceful and prosperous world. SUKHI 222 researches, educates, advocates and participates in development of tools and best practices to insure the biological need and human rights of all people of dignified access to: 2 gallons of fresh water a day, 2,000 nutritional calories and 200 ft.³ of secure shelter. ">
<!--SOCIAL MEDIA-->
    <meta property="og:title" content="WORK WITH THE BEST IN THE WORLD ON LIFE’S MOST URGENT NEEDS" />
    <meta property="og:description" content="Collaborate with other organizations and individuals to build a more peaceful and prosperous world. SUKHI 222 researches, educates, advocates and participates in development of tools and best practices to insure the biological need and human rights of all people of dignified access to: 2 gallons of fresh water a day, 2,000 nutritional calories and 200 ft.³ of secure shelter. " />
    <meta property="og:image" content="http://www.whatever.com/images/header/human-right-project.jpg" />
    <meta name="twitter:card" content="summary_large_image" />
    
   