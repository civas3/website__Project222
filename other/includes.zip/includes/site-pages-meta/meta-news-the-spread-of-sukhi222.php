<title>THE SPREAD OF SUKHI 222</title> 
<!--PAGE META DESCRIPTION-->    
    <meta name="description" content="Food insecurity before the COVID-19 epidemic was a real and immediate crisis in our local community and worldwide. According to feeding America over 37 million people in the United States face hunger on a daily basis.  Over 1 billion people are malnourished worldwide. ">
<!--SOCIAL MEDIA-->
    <meta property="og:title" content="THE SPREAD OF SUKHI 222" />
    <meta property="og:description" content="Food insecurity before the COVID-19 epidemic was a real and immediate crisis in our local community and worldwide. According to feeding America over 37 million people in the United States face hunger on a daily basis.  Over 1 billion people are malnourished worldwide. " />
    <meta property="og:image" content="https://cdn.sukhi222.org//images/feeds/news/the-spread-of-sukhi222/sukhi222-spread.jpg" />
    <meta name="twitter:card" content="summary_large_image" />

