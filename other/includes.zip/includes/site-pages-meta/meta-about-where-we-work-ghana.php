<title>GHANA NON-PROFITSUPPORTING THE UNITED NATION’S SDG’S</title>
<!--PAGE META DESCRIPTION-->    
    <meta name="description" content="SUKHI 222 Nepal is a nonprofit collaborating with SUKHI 222 International to relieve the suffering of people without dignified access to food water and shelter. We support the SDG‘s2030">
<!--SOCIAL MEDIA-->
    <meta property="og:title" content="GHANA NON-PROFITSUPPORTING THE UNITED NATION’S SDG’S" />
    <meta property="og:description" content="SUKHI 222 Nepal is a nonprofit collaborating with SUKHI 222 International to relieve the suffering of people without dignified access to food water and shelter. We support the SDG‘s2030" />
    <meta property="og:image" content="http://www.whatever.com/images/header/human-right-project.jpg" />
    <meta name="twitter:card" content="summary_large_image" />
