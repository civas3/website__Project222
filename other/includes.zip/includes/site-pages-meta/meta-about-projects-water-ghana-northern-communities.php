<title>GHANA NORTHERN COMMUNITIES WATER PROJECT</title>
<!--PAGE META DESCRIPTION-->    
    <meta name="description" content="SUKHI 222 GHANA, an NGO geared toward solving water problems has been all out in its strategic operations in Ghana, specifically at the Northern Communities in the country. ">
<!--SOCIAL MEDIA-->
    <meta property="og:title" content="GHANA NORTHERN COMMUNITIES WATER PROJECT" />
    <meta property="og:description" content="SUKHI 222 GHANA, an NGO geared toward solving water problems has been all out in its strategic operations in Ghana, specifically at the Northern Communities in the country. " />
    <meta property="og:image" content="https://cdn.sukhi222.org/images/projects/water/ghana/ghana-northern-communities.png" />
    <meta name="twitter:card" content="summary_large_image" />

